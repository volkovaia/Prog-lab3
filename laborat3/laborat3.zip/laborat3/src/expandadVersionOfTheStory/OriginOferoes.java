package expandadVersionOfTheStory;

public class OriginOferoes extends TypeOfHero{
    @Override
    public void name() {
        System.out.println("Кристофер Робин");
    }

    @Override
    public void type() {
        System.out.println("Человек");
    }
}
