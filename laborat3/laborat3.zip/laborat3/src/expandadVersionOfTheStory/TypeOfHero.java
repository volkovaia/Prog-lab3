package expandadVersionOfTheStory;

public class TypeOfHero {
    public void name(){
        System.out.println("Имя");
    }
    public void type(){
        System.out.println("Игрушка или человек");
    }


}