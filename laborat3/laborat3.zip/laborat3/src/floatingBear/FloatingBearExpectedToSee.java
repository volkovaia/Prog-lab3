package floatingBear;

public class FloatingBearExpectedToSee implements NotWhatExpectedBear {
    /*public void aboutWinnie(){
        System.out.println("");
    }*/
    public void onABear(){
        System.out.println("'Плавучего медведя'");
    }
    public void thatWasNotIt(){
        System.out.println("Да, это было совсем не то, что");
    }
}
