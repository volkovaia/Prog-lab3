package floatingBear;

public interface NotWhatExpectedBear {
    //public void aboutWinnie();
    public void thatWasNotIt();
    public void onABear();
}
