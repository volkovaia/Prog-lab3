package action;

public interface WinnieMoovies {
    public void lookedIntoTheGround();
    public void triedToPretend();
}
//сначала номера ячейки, потом a, потом команда, потом w, в конце адрес, где +
