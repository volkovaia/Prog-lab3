package action;

public enum SeeStates {
    Watch,
    ExpectToSee

}
