package action;

public interface KristoferMoovies {
    //public void expectToSee();
    //public void watch();
    public void thinkAboutWinnie();
    public void moreThink();
}
