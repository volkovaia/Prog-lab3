package exceptions;

public class PoohQualitiesException  extends Exception{
    public PoohQualitiesException(String message){
        super(message);


    }
}
