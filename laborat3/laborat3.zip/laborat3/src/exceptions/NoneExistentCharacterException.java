package exceptions;


public class NoneExistentCharacterException extends RuntimeException{
    public NoneExistentCharacterException(String message){
        super(message);
    }
}
