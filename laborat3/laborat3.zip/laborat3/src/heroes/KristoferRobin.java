package heroes;

public class KristoferRobin extends General {
    /* public String Kristofer_Robin(){
         super("Кристофер Робин");
     }*/
    public String toString() {
        return "Кристофер Робин";
    }

    @Override
    public String getDescription() {
        return "мальчик";
    }

    //public class RobinMooviesDescription implements KristoferMoovies {
    public static class RobinThinksAboutWinnie extends KristoferRobin {
        public void RobinThinksAboutWinnie(String name, float x, float y, int height) {
            //super(name, x, y, height);
            System.out.println("тем больше он думал о том");
        }
    }

    public static class ThinkMore extends KristoferRobin {
        public void ThinkMore(String name, float x, float y, int height) {
            System.out.println("но чем больше Кристофер Робин думал об этом");

        }
    }
}
    /*public void thinkAboutWinnie() {
            System.out.println("тем больше он думал о том");
        }

        public void moreThink() {
            System.out.println("но чем больше Кристофер Робин думал об этом");
        }

    }*/

