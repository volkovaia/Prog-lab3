package heroes;

public class FloatingBear {
    private String name, constellationtype;
    private InfAboutConstellation infAboutConstellation = new InfAboutConstellation("60", "альфа");
    public FloatingBear (String name, String contellationtype){
        this.name = name;
        this.constellationtype = constellationtype;

    }
    private class InfAboutConstellation {
        private String amountOfStars, mainStar;

        private InfAboutConstellation(String amountOfStars, String mainStar){
            this.amountOfStars = amountOfStars;
            this.mainStar = mainStar;
        }
    }
}
