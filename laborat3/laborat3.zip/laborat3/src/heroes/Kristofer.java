package heroes;

public class Kristofer extends Character{
    /*String type = "Мальчик";
    Kristofer (String name){
        this.name = name;
        this.type = "Мальчик";

    }*/
    public Kristofer (String name, double x, double y, int height){
        this.name = name;
        this.type = "Мальчик";
        this.x = x;
        this.y = y;
        this.force = 10;
        this.height = height;


    }
}
